/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./dateanniversary/index.ts":
/*!**********************************!*\
  !*** ./dateanniversary/index.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.dateanniversary = void 0;\nvar dateanniversary = /** @class */function () {\n  function dateanniversary() {\n    this._selectedDate = null;\n    this._age = null;\n    this._upcomingAnniversary = null;\n  }\n  dateanniversary.prototype.eventListner = function (event) {\n    var inputElement = event.target;\n    this._selectedDate = inputElement.valueAsDate;\n    this._notifyOutputChanged();\n  };\n  dateanniversary.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._container = container;\n    this._selectedDate = context.parameters.sampleProperty.raw || null;\n    this.datePicker = document.createElement(\"input\");\n    this.datePicker.type = \"date\";\n    this.datePicker.valueAsDate = this._selectedDate;\n    this.datePicker.addEventListener(\"change\", this.eventListner.bind(this));\n    this._ageElement = document.createElement(\"div\");\n    this._anniversaryElement = document.createElement(\"div\");\n    container.appendChild(this.datePicker);\n    container.appendChild(this._ageElement);\n    container.appendChild(this._anniversaryElement);\n  };\n  dateanniversary.prototype.calculateAgeAndAnniversary = function () {\n    if (this._selectedDate !== null) {\n      var today = new Date();\n      var birthDate = new Date(this._selectedDate);\n      var years = today.getFullYear() - birthDate.getFullYear();\n      var birthMonth = birthDate.getMonth();\n      var todayMonth = today.getMonth();\n      var age = todayMonth < birthMonth || todayMonth === birthMonth && today.getDate() < birthDate.getDate() ? years - 1 : years;\n      this._ageElement.textContent = \"Age: \".concat(age, \" years\");\n      var upcomingAnniversaryDate = new Date(today.getFullYear(), birthMonth, birthDate.getDate());\n      if (today > upcomingAnniversaryDate) {\n        upcomingAnniversaryDate.setFullYear(upcomingAnniversaryDate.getFullYear() + 1);\n      }\n      var monthNames = [\"January\", \"February\", \"March\", \"April\", \"May\", \"June\", \"July\", \"August\", \"September\", \"October\", \"November\", \"December\"];\n      var formattedDate = \"\".concat(monthNames[upcomingAnniversaryDate.getMonth()], \" \").concat(upcomingAnniversaryDate.getDate(), \", \").concat(upcomingAnniversaryDate.getFullYear());\n      this._anniversaryElement.textContent = \"Upcoming Anniversary: \".concat(formattedDate);\n    } else {\n      this._ageElement.textContent = \"\";\n      this._anniversaryElement.textContent = \"\";\n    }\n  };\n  dateanniversary.prototype.updateView = function (context) {\n    this._selectedDate = context.parameters.sampleProperty.raw || null;\n    this.datePicker.valueAsDate = this._selectedDate;\n    this.calculateAgeAndAnniversary();\n  };\n  dateanniversary.prototype.getOutputs = function () {\n    var outputs = {\n      sampleProperty: this._selectedDate !== null ? this._selectedDate : undefined\n      // ... Other properties ...\n    };\n\n    return outputs;\n  };\n  dateanniversary.prototype.destroy = function () {\n    // Cleanup code if necessary\n  };\n  return dateanniversary;\n}();\nexports.dateanniversary = dateanniversary;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./dateanniversary/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./dateanniversary/index.ts"](0, __webpack_exports__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('DateAnniversary.dateanniversary', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.dateanniversary);
} else {
	var DateAnniversary = DateAnniversary || {};
	DateAnniversary.dateanniversary = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.dateanniversary;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}